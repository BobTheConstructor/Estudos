public class Testador {
    public static void main(String[] args) {

        Diretor f1 = new Diretor("joao","1234", 15000);
        Gerente f2 = new Gerente("marcus", "55554", 10000, 1000);

        System.out.println("\nFuncionario: "+f1.getNome()+"\nCpf: "+ f1.getCPF()+"\nSalario: "+ f1.getSalario()+"\nbonus de: "+f1.getBonificacao());

        System.out.println("\nFuncionario: "+f2.getNome()+"\nCpf: "+ f2.getCPF()+"\nSalario: "+ f2.getSalario()+"\nbonus de: "+f2.getBonificacao());

        ControleBonificacao ctrl = new ControleBonificacao();

        ctrl.registrar(f1);
        ctrl.registrar(f2);

        System.out.println("\nO total de bonificação a ser pago é de : "+ctrl.getTotalSoma());


    }
}
