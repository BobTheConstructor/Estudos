public class ControleBonificacao {
    private double totalSoma;

    public ControleBonificacao() {
        this.totalSoma = 0;
    }

    public void registrar(Funcionario f) {
        totalSoma += f.getBonificacao();
    }

    public double getTotalSoma() {
        return totalSoma;
    }
}
