public class Diretor extends Funcionario {

    public Diretor(String nome, String cpf, double salario) {
        super(nome, cpf, salario);
    }

    @Override
    public double getBonificacao() {
        return (salario * 20)/100;
    }
}