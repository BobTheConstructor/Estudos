public class Funcionario {
    private String nome;
    private String cpf;
    protected double salario;

    public Funcionario(String nome, String cpf, double salario){
        this.nome = nome;
        this.cpf = cpf;
        this.salario = salario;
    };

    public String getNome(){ return nome;}
    public String getCPF(){return cpf;}
    public double getSalario() {return salario;}

    public double getBonificacao(){
        return ((salario * 5) / 100);
    }



}
