public class Gerente extends Funcionario{

    private double bonusFixo;
    public Gerente(String nome, String cpf, double salario, double bonusFixo){
        super(nome, cpf, salario);
        this.bonusFixo = bonusFixo;
    }

    @Override
    public double getBonificacao(){
        return (salario * 12) / 100 + bonusFixo;
    }

}
